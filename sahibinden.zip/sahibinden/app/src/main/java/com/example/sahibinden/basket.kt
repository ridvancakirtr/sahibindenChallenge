package com.example.sahibinden

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class basket : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_basket)
    }
}
